$("#resaltar").click(() => {
  $(".oo").css("background-color", "yellow");
});
