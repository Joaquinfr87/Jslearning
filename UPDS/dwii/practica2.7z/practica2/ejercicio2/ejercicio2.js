$("#ocultar").click(() => {
  $("#lista1 li, #lista2 li").hide();
});

$("#mostrar").click(() => {
  $("#lista1 li, #lista2 li").show();
});
