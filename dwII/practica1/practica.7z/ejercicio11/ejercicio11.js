document.getElementById("zona1").addEventListener("click",()=>{
  alert("Tocaste izquierda arriba");
})
document.getElementById("zona2").addEventListener("click",()=>{
  alert("Tocaste derecha arriba");
})
document.getElementById("zona3").addEventListener("click",()=>{
  alert("Tocaste izquierda abajo");
})
document.getElementById("zona4").addEventListener("click",()=>{
  alert("Tocaste derecha abajo");
})

